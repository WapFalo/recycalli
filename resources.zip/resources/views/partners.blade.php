@extends('layouts.master')

@section('content')
      <!-- partners section start -->
      <div class="about_section layout_padding">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-6">
                  <div class="about_taital_main">
                     <h1 class="about_taital">Nos partenaires</h1>
                     <p class="about_text">RecyCalli ne serait rien sans ses partenaires que nous avons le plaisir de vous présenter ici.</p>
                  </div>
               </div>
               <div class="col-md-6 padding_right_0">
                  <div><img src="images/about_img.png" class="about_img"></div>
            </div>
         </div>
      </div>
      <!-- partners section end -->
@endsection