@extends('layouts.master')

@section('content')
      <!-- contact section start -->
      <div class="contact_section layout_padding">
        <div class="container">
          <h1 class="contact_taital">Un problème ?</h1>
          <div class="email_text">
             <div class="form-group">
                <input type="text" class="email-bt" placeholder="Nom" name="Email">
             </div>
             <div class="form-group">
                <input type="text" class="email-bt" placeholder="Numéro de téléphone" name="Email">
             </div>
             <div class="form-group">
                <input type="text" class="email-bt" placeholder="Email" name="Email">
             </div>
             <div class="form-group">
                <textarea class="massage-bt" placeholder="Message" rows="5" id="comment" name="Massage"></textarea>
             </div>
             <div class="send_btn"><a href="#">ENVOYER</a></div>
          </div>
        </div>
      </div>
      <!-- contact section end -->
@endsection