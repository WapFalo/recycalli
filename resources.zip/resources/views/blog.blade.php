@extends('layouts.master')

@section('content')
      <!-- blog section start -->
      <div class="blog_section layout_padding margin_top_90">
         <div class="container">
            <h1 class="blog_taital">L'upcycling c'est quoi ?</h1>
            <p class="blog_text">L'upcycling, un phénomène qui a fait son petit bout de chemin et on va vous</p>
            <div class="play_icon_main">
               <div class="about_img"><a href="#"><img src="images/about_img.png"></a></div>
            </div>
         </div>
      </div>
      <!-- blog section end -->
      <!-- footer section start -->
      <div class="footer_section layout_padding">
         <div class="container">
            <div class="input_btn_main">
               <input type="text" class="mail_text" placeholder="Entrez votre mail" name="Enter your email">
               <div class="subscribe_bt"><a href="#">Subscribe</a></div>
            </div>
            <div class="location_main">
               <div class="call_text"><img src="images/mail-icon.png"></div>
               <div class="call_text"><a href="#">recycalli@gmail.com</a></div>
            </div>
            <div class="social_icon">
               <ul>
                  <li><a href="#"><img src="images/fb-icon.png"></a></li>
                  <li><a href="#"><img src="images/instagram-icon.png"></a></li>
               </ul>
            </div>
         </div>
      </div>
@endsection