@extends('layouts.master')

@section('content')
      <!-- header section start -->
      
      <!-- header section end -->
      <!-- about section start -->
      <div class="about_section layout_padding">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-6">
                  <div class="about_taital_main">
                     <h1 class="about_taital">Qui sommes-nous ?</h1>
                     <p class="about_text">RecyCalli est un groupe d'étudiants voulant transmettre le gout de l'Upcycling en organisant, entre autres, un grand vide dressing au quartier des chartrons.
                        "Nous pensons qu'il est important pour nous de commencer sérieusement à prendre soin de notre planète et nous essayons avec cette démarche d'y contribuer humblement." - Lucas GILLET, membre de RecyCalli
                     </p>
                     <div class="readmore_bt"><a href="#">En savoir plus</a></div>
                  </div>
               </div>
               <div class="col-md-6 padding_right_0">
                  <div><img src="images/about_img.png" class="about_img"></div>
            </div>
         </div>
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-6 padding_right_0">
                  <div><img src="images/about_img.png" class="about_img"></div>
               </div>
               <div class="col-md-6">
                  <div class="about_taital_main">
                     <h1 class="about_taital">Une tendence en pleine croissance : l'Upcycling</h1>
                     <p class="about_text">Mais alors qu'est-ce que l'Upcycling ? Et surtout, en quoi est-ce si important ? Plus d'informations sur notre blog.</p>
                     <div class="readmore_bt"><a href="blog">Notre blog</a></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about section end -->
@endsection