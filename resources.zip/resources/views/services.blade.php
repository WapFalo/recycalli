@extends('layouts.master')

@section('content')
      <!-- services section start -->
      <div class="services_section layout_padding">
         <div class="container">
            <h1 class="services_taital">Boutique </h1>
            <p class="services_text">Découvrez les articles proposés par nos participants, qui sait ce que vous allez dénicher...</p>
            <div class="services_section_2">
               <div class="row">
                  <div class="col-md-4">
                     <div><img src="images/img-homme.png" class="services_img"></div>
                     <div class="btn_main"><a href="#">Homme</a></div>
                  </div>
                  <div class="col-md-4">
                     <div><img src="images/img-femme.png" class="services_img"></div>
                     <div class="btn_main active"><a href="#">Femme</a></div>
                  </div>
                  <div class="col-md-4">
                     <div><img src="images/img-enfant.png" class="services_img"></div>
                     <div class="btn_main"><a href="#">Enfant</a></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- services section end -->
@endsection