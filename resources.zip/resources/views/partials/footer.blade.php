<div class="footer_section layout_padding">
    <div class="container">
       <div class="input_btn_main">
          <input type="text" class="mail_text" placeholder="Entrez votre mail" name="Enter your email">
          <div class="subscribe_bt"><a href="#">Subscribe</a></div>
       </div>
       <div class="location_main">
          <div class="call_text"><img src="images/mail-icon.png"></div>
          <div class="call_text"><a href="#">recycalli@gmail.com</a></div>
       </div>
       <div class="social_icon">
          <ul>
             <li><a href="#"><img src="images/fb-icon.png"></a></li>
             <li><a href="#"><img src="images/instagram-icon.png"></a></li>
          </ul>
       </div>
    </div>
 </div>
 <!-- footer section end -->
 <!-- copyright section start -->
 <div class="copyright_section">
    <div class="container">
       <p class="copyright_text">2020 All Rights Reserved. Design by <a href="https://html.design">Free html  Templates</a></p>
    </div>
 </div>
 <!-- copyright section end -->